# cosca-runtime — Memory Index

> Cross-reference for fast semantic retrieval. DNA v3.0.

## Memory Files

| File | Purpose | Entries |
|------|---------|---------|
| [learnings.md](learnings.md) | Semantic learning journal | 2 entries |
| [failures.md](failures.md) | Negative memory — failed approaches | 0 failures |
| [patterns.md](patterns.md) | Reusable solution patterns | — (pending) |
| [evolution.md](evolution.md) | Capability evolution timeline | Level 2 |
| [capability-profile.md](capability-profile.md) | Self-model: strengths, weaknesses, confidence | 10 domains scored |

## Metacognition Pipeline

Every task flows through: SELF-ASSESS → RETRIEVE MEMORY → PLAN STRATEGY → EXECUTE → VERIFY RESULT → CRITIQUE OWN WORK → EXTRACT PATTERN → UPDATE CAPABILITY MODEL

See: [workflows/metacognition-pipeline.md](../../../workflows/metacognition-pipeline.md)
